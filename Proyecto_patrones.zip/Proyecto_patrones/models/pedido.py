import datetime
from abc import ABC, abstractmethod

# ==========================================
# 5. STATE (Ciclo de vida del pedido)
# ==========================================
class EstadoPedido(ABC):
    @property
    @abstractmethod
    def nombre(self): pass

    @abstractmethod
    def avanzar(self, pedido): pass

    @abstractmethod
    def cancelar(self, pedido): pass

class EstadoEntregado(EstadoPedido):
    nombre = "ENTREGADO"
    def avanzar(self, pedido): raise Exception("El pedido ya está entregado.")
    def cancelar(self, pedido): raise Exception("No se puede cancelar un pedido entregado.")

class EstadoEnviado(EstadoPedido):
    nombre = "ENVIADO"
    def avanzar(self, pedido): pedido.set_estado(EstadoEntregado())
    def cancelar(self, pedido): raise Exception("No se puede cancelar un pedido enviado.")

class EstadoProcesando(EstadoPedido):
    nombre = "PROCESANDO"
    def avanzar(self, pedido): pedido.set_estado(EstadoEnviado())
    def cancelar(self, pedido): raise Exception("No se puede cancelar en proceso.")

class EstadoCancelado(EstadoPedido):
    nombre = "CANCELADO"
    def avanzar(self, pedido): raise Exception("Un pedido cancelado no puede avanzar.")
    def cancelar(self, pedido): raise Exception("El pedido ya está cancelado.")

class EstadoPendiente(EstadoPedido):
    nombre = "PENDIENTE"
    def avanzar(self, pedido): pedido.set_estado(EstadoProcesando())
    def cancelar(self, pedido): pedido.set_estado(EstadoCancelado()) # Solo se cancela aquí

# ==========================================
# OBSERVER (Notificaciones)
# ==========================================
class Observador(ABC):
    @abstractmethod
    def actualizar(self, pedido):
        pass

class NotificadorCliente(Observador):
    def actualizar(self, pedido):
        print(f"[EMAIL] Notificando a {pedido.cliente}: Tu pedido {pedido.id} ahora está {pedido.estado.nombre}")

class NotificadorAlmacen(Observador):
    def actualizar(self, pedido):
        print(f"[ALMACÉN] El pedido {pedido.id} ha cambiado a {pedido.estado.nombre}")

# ==========================================
# CLASE PEDIDO (Subject para el Observer)
# ==========================================
class Pedido:
    def __init__(self):
        self.id = ""
        self.cliente = ""
        self.tipo_cliente = ""
        self.items = []
        self.subtotal = 0.0
        self.descuento = 0.0
        self.total = 0.0
        self.metodo_pago = None
        self.creado_en = datetime.datetime.now().isoformat()
        self.estado = EstadoPendiente()
        self.observadores = []

    def agregar_observador(self, observador: Observador):
        self.observadores.append(observador)

    def notificar_observadores(self):
        for obs in self.observadores:
            obs.actualizar(self)

    def set_estado(self, nuevo_estado: EstadoPedido):
        self.estado = nuevo_estado
        self.notificar_observadores()

    def to_dict(self):
        return {
            "id": self.id,
            "cliente": self.cliente,
            "tipo_cliente": self.tipo_cliente,
            "estado": self.estado.nombre,
            "items": self.items,
            "subtotal": self.subtotal,
            "descuento": self.descuento,
            "total": self.total,
            "metodo_pago": self.metodo_pago.obtener_nombre() if self.metodo_pago else "",
            "creado_en": self.creado_en
        }
