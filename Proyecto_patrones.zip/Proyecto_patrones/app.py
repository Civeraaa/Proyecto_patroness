from flask import Flask, request, jsonify
from database import db
from models import Producto
from patterns import ConstructorPedido, ComponenteExportacion, ExportadorJSON, ExportadorTexto

app = Flask(__name__)

# ==========================================
# ENDPOINTS DE LA API
# ==========================================

@app.route('/', methods=['GET'])
def index():
    return jsonify({
        "mensaje": "API de gestión de pedidos",
        "endpoints": {
            "GET /productos": "Listar productos",
            "POST /productos": "Crear producto",
            "GET /pedidos": "Listar pedidos",
            "POST /pedidos": "Crear pedido",
            "GET /pedidos/<id>": "Obtener pedido",
            "PUT /pedidos/<id>/confirmar": "Confirmar pedido (procesa pago y pasa a PROCESANDO)",
            "PUT /pedidos/<id>/avanzar": "Avanzar estado",
            "PUT /pedidos/<id>/cancelar": "Cancelar pedido (solo si está PENDIENTE)",
            "GET /pedidos/<id>/exportar?formato=json|texto": "Exportar pedido"
        }
    }), 200

@app.route('/productos', methods=['GET'])
@app.route('/products', methods=['GET'])
def listar_productos():
    return jsonify([p.to_dict() for p in db.productos.values()]), 200

@app.route('/productos', methods=['POST'])
@app.route('/products', methods=['POST'])
def crear_producto():
    data = request.json
    prod_id = data.get("id")
    nuevo_prod = Producto(prod_id, data.get("nombre"), data.get("precio"), data.get("categoria"))
    db.productos[prod_id] = nuevo_prod
    return jsonify(nuevo_prod.to_dict()), 201

@app.route('/pedidos', methods=['POST'])
def crear_pedido():
    data = request.json
    constructor = ConstructorPedido()
    tipo_cliente = data.get("tipo_cliente", data.get("tipo cliente"))
    metodo_pago = data.get("metodo_pago", data.get("metodo pago"))
    pedido = (constructor.set_cliente(data.get("cliente"), tipo_cliente)
                         .set_metodo_pago(metodo_pago)
                         .add_items(data.get("items", []), db)
                         .aplicar_estrategia_descuento()
                         .build(db))
    
    db.pedidos[pedido.id] = pedido
    return jsonify(pedido.to_dict()), 201

@app.route('/pedidos', methods=['GET'])
def listar_pedidos():
    return jsonify([p.to_dict() for p in db.pedidos.values()]), 200

@app.route('/pedidos/<id>', methods=['GET'])
def obtener_pedido(id):
    pedido = db.pedidos.get(id)
    if not pedido: return jsonify({"error": "Pedido no encontrado"}), 404
    return jsonify(pedido.to_dict()), 200

@app.route('/pedidos/<id>/avanzar', methods=['PUT'])
def avanzar_pedido(id):
    pedido = db.pedidos.get(id)
    if not pedido: return jsonify({"error": "Pedido no encontrado"}), 404
    
    try:
        pedido.estado.avanzar(pedido)
        return jsonify(pedido.to_dict()), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/pedidos/<id>/confirmar', methods=['PUT'])
def confirmar_pedido(id):
    pedido = db.pedidos.get(id)
    if not pedido: return jsonify({"error": "Pedido no encontrado"}), 404

    if not pedido.metodo_pago:
        return jsonify({"error": "Método de pago no asignado"}), 400

    if pedido.estado.nombre != "PENDIENTE":
        return jsonify({"error": "Solo se puede confirmar un pedido en estado PENDIENTE"}), 400

    try:
        ok = pedido.metodo_pago.procesar_pago(pedido.total)
        if not ok:
            return jsonify({"error": "Pago rechazado"}), 400

        pedido.estado.avanzar(pedido)
        return jsonify(pedido.to_dict()), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/pedidos/<id>/cancelar', methods=['PUT'])
def cancelar_pedido(id):
    pedido = db.pedidos.get(id)
    if not pedido: return jsonify({"error": "Pedido no encontrado"}), 404
    
    try:
        pedido.estado.cancelar(pedido)
        return jsonify(pedido.to_dict()), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/pedidos/<id>/exportar', methods=['GET'])
def exportar_pedido(id):
    pedido = db.pedidos.get(id)
    if not pedido: return jsonify({"error": "Pedido no encontrado"}), 404
    
    formato = (request.args.get('formato') or request.args.get('format') or 'json').lower()
    componente_base = ComponenteExportacion(pedido)
    
    if formato == 'texto':
        exportador = ExportadorTexto(componente_base)
        return exportador.exportar(), 200, {'Content-Type': 'text/plain'}
    else:
        exportador = ExportadorJSON(componente_base)
        return exportador.exportar(), 200, {'Content-Type': 'application/json'}

if __name__ == '__main__':
    # Agregar productos de ejemplo
    db.productos['laptop'] = Producto('laptop', 'Laptop Gaming', 1200.0, 'Electrónica')
    db.productos['mouse'] = Producto('mouse', 'Mouse RGB', 25.0, 'Accesorios')
    db.productos['teclado'] = Producto('teclado', 'Teclado Mecánico', 80.0, 'Accesorios')
    
    app.run(debug=True)
