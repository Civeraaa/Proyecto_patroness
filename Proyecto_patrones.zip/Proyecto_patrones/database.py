# ==========================================
# 1. SINGLETON (Base de Datos en Memoria)
# ==========================================
class MemoriaDB:
    _instancia = None

    def __new__(cls):
        if cls._instancia is None:
            cls._instancia = super(MemoriaDB, cls).__new__(cls)
            cls._instancia.productos = {}
            cls._instancia.pedidos = {}
            cls._instancia.contador_pedidos = 1
        return cls._instancia

# Crear instancia global
db = MemoriaDB()
