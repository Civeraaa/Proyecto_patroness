# API REST Gestión de Pedidos (Flask + Patrones GoF)

## Objetivo
API REST en Flask que simula la gestión de pedidos de una tienda online, aplicando patrones GoF.

## Patrones implementados
- **Singleton**: base de datos en memoria (`database.py`).
- **Factory Method**: métodos de pago (`patterns/factory.py`).
- **Builder**: construcción del pedido (`patterns/builder.py`).
- **Strategy**: descuentos por tipo de cliente (`patterns/strategy.py`).
- **State**: ciclo de vida del pedido (`models/pedido.py`).
- **Observer**: notificaciones al cambiar de estado (`models/pedido.py`).
- **Decorator**: exportación JSON/texto (`patterns/decorator.py`).

## Endpoints
- **GET** `/productos` : listar productos
- **POST** `/productos` : crear producto
- **POST** `/pedidos` : crear pedido (productos+cantidades, descuento, método de pago)
- **GET** `/pedidos` : listar pedidos
- **GET** `/pedidos/<id>` : detalle de pedido
- **PUT** `/pedidos/<id>/confirmar` : procesar pago (simulado) y pasar a `PROCESANDO`
- **PUT** `/pedidos/<id>/avanzar` : avanzar estado (`PENDIENTE->PROCESANDO->ENVIADO->ENTREGADO`)
- **PUT** `/pedidos/<id>/cancelar` : cancelar (solo si `PENDIENTE`)
- **GET** `/pedidos/<id>/exportar?formato=json|texto` : exportar pedido

## Ejemplos de JSON
### Producto
```json
{ "id":"p1", "nombre":"Laptop", "precio":1200.0, "categoria":"Electrónica" }
```

### Pedido (request)
```json
{
  "cliente": "Ana García",
  "tipo_cliente": "premium",
  "metodo_pago": "paypal",
  "items": [ { "producto id": "p1", "cantidad": 2 } ]
}
```

## Ejecución
```bash
pip install Flask
python app.py
```
Servidor: `http://127.0.0.1:5000`
