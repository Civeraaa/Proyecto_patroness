from abc import ABC, abstractmethod

# ==========================================
# 2. STRATEGY (Descuentos según cliente)
# ==========================================
class EstrategiaDescuento(ABC):
    @abstractmethod
    def calcular_descuento(self, subtotal: float) -> float:
        pass

class DescuentoNormal(EstrategiaDescuento):
    def calcular_descuento(self, subtotal: float) -> float:
        return 0.0

class DescuentoPremium(EstrategiaDescuento):
    def calcular_descuento(self, subtotal: float) -> float:
        return round(subtotal * 0.10, 2) # 10% descuento

class DescuentoVIP(EstrategiaDescuento):
    def calcular_descuento(self, subtotal: float) -> float:
        return round(subtotal * 0.20, 2) # 20% descuento
