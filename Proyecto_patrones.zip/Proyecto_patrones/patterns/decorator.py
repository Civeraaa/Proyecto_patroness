import json
from abc import ABC, abstractmethod

# ==========================================
# 7. DECORATOR (Exportación)
# ==========================================
class ExportadorBase(ABC):
    @abstractmethod
    def exportar(self) -> str: pass

class ComponenteExportacion(ExportadorBase):
    def __init__(self, pedido):
        self.pedido = pedido
    def exportar(self):
        return self.pedido.to_dict()

class ExportadorJSON(ExportadorBase):
    def __init__(self, componente: ExportadorBase):
        self.componente = componente
    def exportar(self):
        return json.dumps(self.componente.exportar(), indent=2)

class ExportadorTexto(ExportadorBase):
    def __init__(self, componente: ExportadorBase):
        self.componente = componente
    def exportar(self):
        datos = self.componente.exportar()
        texto = f"--- PEDIDO {datos['id']} ---\n"
        texto += f"Cliente: {datos['cliente']} ({datos['tipo_cliente']})\n"
        texto += f"Estado: {datos['estado']}\n"
        texto += f"Total: ${datos['total']}\n"
        texto += f"Pago: {datos['metodo_pago']}\n"
        return texto
