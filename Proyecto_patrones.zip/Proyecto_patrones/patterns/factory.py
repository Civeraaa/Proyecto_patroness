from abc import ABC, abstractmethod

# ==========================================
# 3. FACTORY METHOD (Métodos de Pago)
# ==========================================
class MetodoPago(ABC):
    @abstractmethod
    def obtener_nombre(self) -> str:
        pass

    @abstractmethod
    def procesar_pago(self, monto: float) -> bool:
        pass

class PagoTarjeta(MetodoPago):
    def obtener_nombre(self): return "Tarjeta de Crédito"
    def procesar_pago(self, monto: float) -> bool:
        return True

class PagoPayPal(MetodoPago):
    def obtener_nombre(self): return "PayPal"
    def procesar_pago(self, monto: float) -> bool:
        return True

class PagoTransferencia(MetodoPago):
    def obtener_nombre(self): return "Transferencia Bancaria"
    def procesar_pago(self, monto: float) -> bool:
        return True

class FabricaPago:
    @staticmethod
    def crear_metodo(tipo: str) -> MetodoPago:
        tipo = tipo.lower()
        if tipo == "paypal": return PagoPayPal()
        elif tipo == "tarjeta": return PagoTarjeta()
        elif tipo == "transferencia": return PagoTransferencia()
        else: return PagoTarjeta() # Por defecto
