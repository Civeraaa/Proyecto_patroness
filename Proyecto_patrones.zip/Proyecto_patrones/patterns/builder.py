# ==========================================
# 6. BUILDER (Construcción de Pedido)
# ==========================================
class ConstructorPedido:
    def __init__(self):
        self.pedido = None
        # Importación tardía para evitar importación circular
        from models.pedido import Pedido
        self.pedido = Pedido()

    def set_cliente(self, cliente: str, tipo_cliente: str):
        self.pedido.cliente = cliente
        self.pedido.tipo_cliente = tipo_cliente.lower()
        return self

    def set_metodo_pago(self, metodo_str: str):
        from patterns.factory import FabricaPago
        self.pedido.metodo_pago = FabricaPago.crear_metodo(metodo_str)
        return self

    def add_items(self, items_request: list, db):
        subtotal = 0.0
        detalle_items = []
        for item in items_request:
            prod_id = (
                item.get("producto_id")
                or item.get("producto id")
                or item.get("productoId")
                or item.get("id_producto")
                or item.get("product_id")
            )
            cantidad = item.get("cantidad", item.get("qty", 1))
            if prod_id in db.productos:
                prod = db.productos[prod_id]
                subtotal += prod.precio * cantidad
                detalle_items.append({"producto": prod.to_dict(), "cantidad": cantidad})
        
        self.pedido.items = detalle_items
        self.pedido.subtotal = subtotal
        return self

    def aplicar_estrategia_descuento(self):
        from patterns.strategy import DescuentoVIP, DescuentoPremium, DescuentoNormal
        
        if self.pedido.tipo_cliente == "vip":
            estrategia = DescuentoVIP()
        elif self.pedido.tipo_cliente == "premium":
            estrategia = DescuentoPremium()
        else:
            estrategia = DescuentoNormal()
            
        self.pedido.descuento = estrategia.calcular_descuento(self.pedido.subtotal)
        self.pedido.total = self.pedido.subtotal - self.pedido.descuento
        return self

    def build(self, db):
        self.pedido.id = f"ord-{str(db.contador_pedidos).zfill(3)}"
        db.contador_pedidos += 1
        # Añadimos observadores por defecto
        from models.pedido import NotificadorCliente, NotificadorAlmacen
        self.pedido.agregar_observador(NotificadorCliente())
        self.pedido.agregar_observador(NotificadorAlmacen())
        return self.pedido
